# Install Portable Downloads on Unraid

This alpha has two parts: a Jellyfin server plugin and a Jellyfin Web download-menu integration. The DLL alone does not change a native Moonfin/mobile app. Keep a backup and try one short SDR episode first.

## Choose the correct package

Check Dashboard > General/About for your server version.

- `portable-downloads-0.1.0-jellyfin-10.11.11.zip`: built and runtime-tested on 10.11.11.
- `portable-downloads-0.1.0-jellyfin-12.1.0.zip`: builds against 12.1.0; runtime testing is still required.
- Do not install both, and do not assume compatibility with 10.10 or other releases.

Downloads are on the private [GitHub release page](https://github.com/RulerOfNobody/jellyfin-portable-downloads/releases). Sign into your authorized GitHub account to download. Do not paste a GitHub personal token into a Jellyfin catalog URL. Keep this repository private unless you intentionally choose to publish it.

## Prepare temporary storage

Mount the SSD in Unraid first. Create a dedicated folder on it, outside all scanned media libraries. An example host location is `/mnt/disks/YOUR_SSD/portable-downloads`; replace it with the actual path from your setup.

Add a **Path** mapping to your Jellyfin Docker container:

```text
Host path:      /mnt/disks/YOUR_SSD/portable-downloads
Container path: /portable-downloads
Access mode:    Read/Write
```

Give the container's runtime user write access. Do not change ownership of your whole media library or give the container privileged access just for this plugin. Existing GPU passthrough must remain as configured for Jellyfin.

Create a file named `.portable-downloads-volume` directly in that host folder containing:

```text
portable-downloads
```

The matching text proves that the configured scratch folder exists on the intended mounted storage. Use a unique marker string if multiple scratch volumes could be swapped. Do not put the marker in an underlying unmounted fallback directory. Symlinked scratch paths are rejected.

Do not use Jellyfin's shared cache/transcoding directory, a media library, or the config/appdata directory as the scratch folder. Keep plugin state on healthy appdata storage. The plugin does not mount, format, repair, or discover raw physical drives.

## Install the DLL

1. Stop Jellyfin.
2. Find its persistent plugins directory inside the `/config` mapping. Typical images use `/config/plugins`, but layouts vary. Use the plugin path shown in your Jellyfin logs if different.
3. Create a `PortableDownloads` subdirectory there.
4. Extract `Jellyfin.Plugin.Portable.dll` from the matching release ZIP into that subdirectory. Do not copy Jellyfin core DLLs alongside it.
5. Start Jellyfin and confirm **Portable Downloads** appears in Dashboard > Plugins.
6. Open its settings. Set the temporary directory to `/portable-downloads`, retention to 24 hours, quota, free-space reserve and queue limits.
7. Save, then click **Test saved scratch settings**.

This manual ZIP process is intentional: private GitHub release assets cannot be downloaded anonymously by Jellyfin's ordinary plugin catalog.

## Configure hardware in Jellyfin, not in the plugin

In Dashboard > Playback > Transcoding, keep your existing acceleration backend and device. The plugin reads these settings when preparing each job and uses Jellyfin's `EncodingHelper` to build its encode command.

- Leave hardware encoding enabled if you want GPU encoding.
- Enable HEVC/AV1 encoding there if you want those output options.
- Enable and test tone mapping before queuing HDR movies.
- Keep the existing `/dev/dri` or NVIDIA device/environment mappings in the container.
- If a codec cannot be encoded by the selected hardware, choose a different codec. The plugin does not silently choose the CPU or another GPU.
- If Jellyfin itself is configured for software encoding, the plugin follows that.

Inspect the queue's encoder label and Jellyfin server logs during the first encode. For example, `h264_qsv`, `hevc_vaapi`, or `av1_nvenc` indicates the selected encoder; driver/device validity must be confirmed on your machine.

## Enable the Download dialog

For **Jellyfin Web 10.11.11**, the release includes an adapted full web build:

1. Extract `jellyfin-web-10.11.11-portable-0.1.0.zip` into a dedicated persistent host folder.
2. Bind-mount that folder over your image's Jellyfin Web directory, read-only. The official image commonly uses `/jellyfin/jellyfin-web`; other images can use `/usr/share/jellyfin/web`. Confirm the actual **Web resources path** in your server logs first.
3. Restart Jellyfin and clear the browser's Jellyfin site cache/service worker if it still shows the old interface.
4. Open the server-hosted Jellyfin Web page. Select a movie/episode, choose **More options > Download**, and the options dialog should open.

**Never overlay this 10.11.11 web build onto another server/web version.** For other versions, use the source adapter workflow in [WEB-INTEGRATION.md](docs/WEB-INTEGRATION.md), then test that exact build.

The adapted web build is pinned; remove/update its bind mount when upgrading Jellyfin. Otherwise an old web interface will hide the image's new web files.

## Use it

- Choose Download for a movie or episode.
- For a season/series, use the client's **Download all** action where available. The dialog shows individual sliders and audio/subtitle choices per item.
- Select the codec and resolution for the batch, and sizes for each file.
- Click **Prepare download**. View progress under **Your downloads**.
- When ready, click **Download file**. Use the browser download manager and a compatible local video player.
- **Offline downloads** reopens the queue after the dialog has been loaded. After a page reload, open Download on a video once to reload the integration.
- Expiration affects the server copy only. The copy on your phone stays until you remove it.

HTTPS is recommended outside your LAN. Download URLs contain short-lived file-scoped tickets; avoid logging their query strings in a reverse proxy. They are not Jellyfin account tokens. Resuming after ticket expiry requires clicking Download again for a fresh ticket.

## Rollback

Stop Jellyfin, remove the `PortableDownloads` plugin directory and the custom web bind mount, then restart. Originals are untouched. The dedicated scratch folder may contain disposable `portable-<job-id>` directories; inspect it before manually deleting anything. Plugin job state remains under Jellyfin's data directory in `portable-downloads/jobs.json`.
