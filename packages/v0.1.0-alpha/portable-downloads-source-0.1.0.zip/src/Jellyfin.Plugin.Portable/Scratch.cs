namespace Jellyfin.Plugin.Portable;

public static class Scratch
{
    public static string ValidateRoot(string path, string marker)
    {
        if (string.IsNullOrWhiteSpace(path) || !Path.IsPathFullyQualified(path))
            throw new ArgumentException("Scratch path must be an absolute container-visible path.");
        var root = Path.TrimEndingDirectorySeparator(Path.GetFullPath(path));
        if (root.IndexOfAny(['"', '\r', '\n']) >= 0) throw new ArgumentException("Scratch path contains unsupported characters.");
        if (root == Path.GetPathRoot(root) || !Directory.Exists(root))
            throw new ArgumentException("Scratch directory must already exist and cannot be a filesystem root.");
        RejectLinks(root);
        var markerPath = Path.Combine(root, ".portable-downloads-volume");
        if (!File.Exists(markerPath) || File.ReadAllText(markerPath).Trim() != marker)
            throw new IOException("Scratch volume marker is missing or does not match. Refusing to write to a missing/replaced mount.");
        return root;
    }
    public static void RejectLinks(string path)
    {
        for (var p = new DirectoryInfo(path); p != null; p = p.Parent)
            if (p.LinkTarget != null) throw new IOException("Symlinked scratch directories are not allowed.");
    }
    public static string DirectoryFor(Job job) => Path.Combine(ValidateRoot(job.ScratchRoot, job.Marker), "portable-" + job.Id.ToString("N"));
    public static string OutputFor(Job job) => Path.Combine(DirectoryFor(job), "download.mp4");
    public static void EnsureSpace(string root, long needed, long reserve)
    {
        var drive = DriveInfo.GetDrives().Where(d => root == Path.TrimEndingDirectorySeparator(d.Name)
            || root.StartsWith(d.Name.EndsWith(Path.DirectorySeparatorChar) ? d.Name : d.Name + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            .OrderByDescending(d => d.Name.Length).FirstOrDefault();
        if (drive == null || !drive.IsReady || drive.AvailableFreeSpace < needed + reserve)
            throw new IOException("Insufficient scratch space, or the scratch volume is unavailable.");
    }
    public static void Delete(Job job)
    {
        var dir = DirectoryFor(job);
        if (!Directory.Exists(dir)) return;
        RejectLinks(dir);
        // Never recursive-delete arbitrary content, and never follow links.
        foreach (var file in Directory.EnumerateFiles(dir))
        {
            var info = new FileInfo(file);
            if (info.LinkTarget != null) throw new IOException("Unexpected symlink in job directory.");
            if (info.Name is not ("download.mp4" or "encoding.mp4")) throw new IOException("Unexpected file in job directory; cleanup stopped.");
            info.Delete();
        }
        Directory.Delete(dir, false);
    }
}
