using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Jellyfin.Plugin.Portable;

[ApiController]
[Route("PortableDownloads")]
[Authorize]
public sealed class PortableController(MediaAccess access, JobService jobs, EncodingService encoding) : ControllerBase
{
    [HttpGet("settings")]
    public ActionResult Settings() => Guard(() => { access.UserId(User); return Ok(encoding.Settings()); });
    [HttpGet("items/{id:guid}")]
    public ActionResult Item(Guid id) => Guard(() => Ok(access.Describe(access.UserId(User), id)));
    [HttpGet("jobs")]
    public ActionResult Jobs() => Guard(() => Ok(jobs.List(access.UserId(User))));
    [HttpPost("jobs")]
    public ActionResult Create([FromBody] DownloadRequest[] requests) => Guard(() => Ok(jobs.Enqueue(access.UserId(User), requests)));
    [HttpDelete("jobs/{id:guid}")]
    public ActionResult Cancel(Guid id) => Guard(() => { jobs.Cancel(access.UserId(User), id); return NoContent(); });
    [HttpPost("jobs/{id:guid}/ticket")]
    public ActionResult Ticket(Guid id) => Guard(() => Ok(new { ticket = jobs.Ticket(access.UserId(User), id) }));

    // A scoped, expiring random ticket authorizes only this output file, not Jellyfin itself.
    // This permits streaming to the browser's download manager without loading GBs into JS memory.
    [AllowAnonymous]
    [HttpGet("jobs/{id:guid}/file")]
    public ActionResult Download(Guid id, [FromQuery] string ticket) => Guard(() =>
    {
        var opened = jobs.Open(id, ticket);
        Response.Headers.CacheControl = "private, no-store";
        Response.Headers["Referrer-Policy"] = "no-referrer";
        Response.OnCompleted(() => { opened.Release(); return Task.CompletedTask; });
        return File(opened.Stream, "video/mp4", opened.Name, enableRangeProcessing: true);
    });

    [HttpPost("storage/test")]
    public ActionResult TestStorage() => Guard(() =>
    {
        if (!access.IsAdmin(access.UserId(User))) throw new UnauthorizedAccessException();
        var cfg = Plugin.Instance.Configuration;
        var root = Scratch.ValidateRoot(cfg.ScratchPath, cfg.ScratchMarker);
        var probe = Path.Combine(root, ".portable-write-" + Guid.NewGuid().ToString("N"));
        try { System.IO.File.WriteAllText(probe, "test"); } finally { if (System.IO.File.Exists(probe)) System.IO.File.Delete(probe); }
        Scratch.EnsureSpace(root, 0, Math.Clamp(cfg.ReserveGB, 1, 1000) * Rules.GB);
        return Ok(new { writable = true, path = root });
    });

    // These two public assets contain no data, tokens, or configuration.
    [AllowAnonymous]
    [HttpGet("ui/{asset}")]
    public ActionResult Asset(string asset)
    {
        if (asset is not ("portable.js" or "portable.css")) return NotFound();
        var stream = typeof(Plugin).Assembly.GetManifestResourceStream("Portable." + asset);
        return stream == null ? NotFound() : File(stream, asset.EndsWith(".js") ? "text/javascript" : "text/css");
    }
    private ActionResult Guard(Func<ActionResult> action)
    {
        try { return action(); }
        catch (UnauthorizedAccessException) { return StatusCode(403, new { error = "You do not have permission for this item or download." }); }
        catch (ArgumentException ex) { return BadRequest(new { error = ex.Message }); }
        catch (IOException ex) { return StatusCode(409, new { error = ex.Message }); }
    }
}
