using MediaBrowser.Common.Configuration;
using MediaBrowser.Common.Plugins;
using MediaBrowser.Controller;
using MediaBrowser.Controller.Plugins;
using MediaBrowser.Model.Plugins;
using MediaBrowser.Model.Serialization;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Jellyfin.Plugin.Portable;

public sealed class Plugin : BasePlugin<PluginConfiguration>, IHasWebPages
{
    public static Plugin Instance { get; private set; } = null!;
    public Plugin(IApplicationPaths paths, IXmlSerializer serializer) : base(paths, serializer) => Instance = this;
    public override string Name => "Portable Downloads";
    public override string Description => "Temporary, size-budgeted offline video downloads using Jellyfin's encoder settings.";
    public override Guid Id => Guid.Parse("9ab61945-dd21-43f9-86ec-9c1144374cac");
    public IEnumerable<PluginPageInfo> GetPages() =>
    [
        new() { Name = "PortableDownloads", EmbeddedResourcePath = "Jellyfin.Plugin.Portable.Configuration.configPage.html" }
    ];
}

public sealed class PluginConfiguration : BasePluginConfiguration
{
    // No auto-created scratch directory: require an existing, intentionally mounted directory.
    public string ScratchPath { get; set; } = "/portable-downloads";
    public string ScratchMarker { get; set; } = "portable-downloads";
    public int RetentionHours { get; set; } = 24;
    public int QuotaGB { get; set; } = 100;
    public int ReserveGB { get; set; } = 5;
    public int MaxJobsPerUser { get; set; } = 20;
    public int MaxTotalJobs { get; set; } = 100;
    public int MaxEncodeHours { get; set; } = 12;
}

public sealed class ServiceRegistrator : IPluginServiceRegistrator
{
    public void RegisterServices(IServiceCollection services, IServerApplicationHost host)
    {
        services.AddSingleton<MediaAccess>();
        services.AddSingleton<EncodingService>();
        services.AddSingleton<JobService>();
        services.AddSingleton<IHostedService>(sp => sp.GetRequiredService<JobService>());
    }
}
