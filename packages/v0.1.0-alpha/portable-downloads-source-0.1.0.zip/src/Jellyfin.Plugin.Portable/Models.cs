using System.Text.Json.Serialization;

namespace Jellyfin.Plugin.Portable;

public sealed record DownloadRequest(Guid ItemId, double SizeGB = 6, string Codec = "h264",
    int Height = 1080, int? AudioIndex = null, int? SubtitleIndex = null);

public sealed class Job
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }
    public DownloadRequest Request { get; set; } = new(Guid.Empty);
    public string Title { get; set; } = "";
    public string State { get; set; } = "queued";
    public string? Error { get; set; }
    public string? Encoder { get; set; }
    public double Progress { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? ExpiresAt { get; set; }
    public long? Bytes { get; set; }
    public string ScratchRoot { get; set; } = "";
    public string Marker { get; set; } = "";
    [JsonIgnore] public int ActiveDownloads;
    [JsonIgnore] public CancellationTokenSource? Cancellation;
    public object Public() => new
    {
        id = Id, itemId = Request.ItemId, title = Title, state = State, error = Error,
        encoder = Encoder, progress = Progress, createdAt = CreatedAt, expiresAt = ExpiresAt,
        bytes = Bytes, sizeGB = Request.SizeGB, codec = Request.Codec, height = Request.Height
    };
}

public static class Rules
{
    public const long GB = 1_000_000_000;
    public static void Validate(DownloadRequest request)
    {
        if (request.ItemId == Guid.Empty) throw new ArgumentException("A library item is required.");
        if (!double.IsFinite(request.SizeGB) || request.SizeGB < 0.25 || request.SizeGB > 20)
            throw new ArgumentException("Size must be between 0.25 and 20 decimal GB.");
        if (request.Codec is not ("h264" or "hevc" or "av1")) throw new ArgumentException("Unsupported codec.");
        if (request.Height is not (480 or 720 or 1080)) throw new ArgumentException("Choose 480p, 720p, or 1080p.");
        if (request.AudioIndex < 0 || request.SubtitleIndex < 0) throw new ArgumentException("Invalid stream index.");
    }
    public static int VideoBitrate(double sizeGB, double seconds)
    {
        if (!double.IsFinite(seconds) || seconds <= 0) throw new ArgumentException("Media duration is unavailable.");
        // Reserve 3% for muxing/rate-control variation, plus 192 kbps AAC.
        var rate = sizeGB * GB * 8 * 0.97 / seconds - 192_000;
        if (rate < 150_000) throw new ArgumentException("Size is too small for this duration. Increase the size.");
        return (int)Math.Min(rate, 40_000_000);
    }
    public static bool HardwareExpected(string type, bool enabled) =>
        enabled && !string.IsNullOrWhiteSpace(type) && !type.Equals("none", StringComparison.OrdinalIgnoreCase);
    public static void CheckHardware(string type, bool enabled, string encoder)
    {
        if (HardwareExpected(type, enabled) && encoder.StartsWith("lib", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException($"Jellyfin's {type} backend cannot encode the selected codec. Choose another format; CPU fallback is disabled.");
    }
}
