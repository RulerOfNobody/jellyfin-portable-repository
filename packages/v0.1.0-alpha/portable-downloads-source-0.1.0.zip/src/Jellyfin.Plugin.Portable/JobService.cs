using System.Security.Cryptography;
using System.Text.Json;
using MediaBrowser.Common.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Jellyfin.Plugin.Portable;

public sealed class JobService : BackgroundService
{
    private readonly object gate = new();
    private readonly List<Job> jobs = [];
    private readonly Dictionary<string, (Guid JobId, Guid UserId, DateTimeOffset Expires)> tickets = [];
    private readonly EncodingService encoding;
    private readonly MediaAccess access;
    private readonly ILogger<JobService> logger;
    private readonly string stateFile;
    public JobService(IApplicationPaths paths, EncodingService encoding, MediaAccess access, ILogger<JobService> logger)
    {
        this.encoding = encoding;
        this.access = access;
        this.logger = logger;
        var dir = Path.Combine(paths.DataPath, "portable-downloads");
        Directory.CreateDirectory(dir);
        stateFile = Path.Combine(dir, "jobs.json");
        if (File.Exists(stateFile))
        {
            try
            {
                jobs = JsonSerializer.Deserialize<List<Job>>(File.ReadAllText(stateFile)) ?? [];
                foreach (var job in jobs.Where(j => j.State is "encoding" or "queued"))
                {
                    job.State = "failed";
                    job.Error = "Server restarted before the job finished. Submit a new download.";
                }
            }
            catch (Exception ex)
            {
                // Do not overwrite unreadable state and thereby orphan cleanup ownership.
                logger.LogError(ex, "Portable Downloads state could not be read");
                throw new IOException("Portable Downloads job state is unreadable; restore or move jobs.json before enabling the plugin.", ex);
            }
        }
    }
    public object[] List(Guid userId)
    {
        lock (gate) return jobs.Where(j => j.UserId == userId).OrderByDescending(j => j.CreatedAt).Select(j => j.Public()).ToArray();
    }
    public object[] Enqueue(Guid userId, DownloadRequest[] requests)
    {
        var cfg = Plugin.Instance.Configuration;
        if (requests.Length < 1 || requests.Length > Math.Clamp(cfg.MaxJobsPerUser, 1, 100))
            throw new ArgumentException("Invalid batch size.");
        // Resolve every item and validate encoder choices before reserving storage.
        var prepared = requests.Select(request =>
        {
            Rules.Validate(request);
            var (item, _) = access.Get(userId, request.ItemId);
            encoding.Plan(userId, request, "/validation/encoding.mp4");
            return new Job { UserId = userId, Request = request, Title = item.Name };
        }).ToArray();
        var root = Scratch.ValidateRoot(cfg.ScratchPath, cfg.ScratchMarker);
        lock (gate)
        {
            var live = jobs.Where(j => j.State is "queued" or "encoding" or "ready").ToArray();
            if (live.Count(j => j.UserId == userId) + prepared.Length > Math.Clamp(cfg.MaxJobsPerUser, 1, 100)
                || live.Length + prepared.Length > Math.Clamp(cfg.MaxTotalJobs, 1, 500))
                throw new ArgumentException("Download queue limit reached. Cancel or delete older jobs first.");
            var needed = prepared.Sum(j => j.Request.SizeGB * Rules.GB * 1.15);
            var reserved = live.Sum(j => Math.Max(j.Bytes ?? 0, j.Request.SizeGB * Rules.GB * 1.15));
            if (needed + reserved > Math.Clamp(cfg.QuotaGB, 1, 10000) * Rules.GB)
                throw new IOException("The plugin scratch quota is full.");
            // faststart can temporarily require a second file-sized allocation.
            Scratch.EnsureSpace(root, (long)needed * 2, Math.Clamp(cfg.ReserveGB, 1, 1000) * Rules.GB);
            foreach (var j in prepared) { j.ScratchRoot = root; j.Marker = cfg.ScratchMarker; }
            jobs.AddRange(prepared);
            try { Save(); } catch { foreach (var j in prepared) jobs.Remove(j); throw; }
            return prepared.Select(j => j.Public()).ToArray();
        }
    }
    public void Cancel(Guid userId, Guid id)
    {
        lock (gate)
        {
            var job = Owned(userId, id);
            if (job.ActiveDownloads > 0) throw new ArgumentException("This file is currently downloading. Try again after the transfer finishes.");
            if (job.State == "encoding") job.Cancellation?.Cancel();
            else
            {
                Scratch.Delete(job);
                job.State = "cancelled";
                job.Error = null;
            }
            Save();
        }
    }
    public string Ticket(Guid userId, Guid id)
    {
        lock (gate)
        {
            var job = Owned(userId, id);
            access.Get(userId, job.Request.ItemId); // permissions may have changed since encoding
            if (job.State != "ready" || job.ExpiresAt <= DateTimeOffset.UtcNow) throw new ArgumentException("File is not ready or has expired.");
            PruneTickets();
            foreach (var key in tickets.Where(t => t.Value.JobId == id).Select(t => t.Key).ToArray()) tickets.Remove(key);
            var token = Convert.ToHexString(RandomNumberGenerator.GetBytes(32)).ToLowerInvariant();
            tickets[token] = (id, userId, DateTimeOffset.UtcNow.AddHours(2));
            return token;
        }
    }
    public (FileStream Stream, string Name, Action Release) Open(Guid id, string token)
    {
        lock (gate)
        {
            PruneTickets();
            if (!tickets.TryGetValue(token, out var ticket) || ticket.JobId != id) throw new UnauthorizedAccessException();
            var job = Owned(ticket.UserId, id);
            access.Get(ticket.UserId, job.Request.ItemId);
            if (job.State != "ready" || job.ExpiresAt <= DateTimeOffset.UtcNow) throw new ArgumentException("File expired.");
            var file = Scratch.OutputFor(job);
            Scratch.RejectLinks(Path.GetDirectoryName(file)!);
            if (new FileInfo(file).LinkTarget != null) throw new IOException("Unexpected output symlink.");
            var released = 0;
            Action release = () =>
            {
                if (Interlocked.Exchange(ref released, 1) == 0) lock (gate) job.ActiveDownloads--;
            };
            var stream = new LeasedFileStream(file, release);
            job.ActiveDownloads++;
            return (stream, "portable-" + id.ToString("N")[..8] + ".mp4", release);
        }
    }
    private Job Owned(Guid userId, Guid id) =>
        jobs.FirstOrDefault(j => j.Id == id && j.UserId == userId) ?? throw new UnauthorizedAccessException();
    private void PruneTickets()
    {
        foreach (var key in tickets.Where(t => t.Value.Expires < DateTimeOffset.UtcNow).Select(t => t.Key).ToArray()) tickets.Remove(key);
    }
    private void Save()
    {
        var temporary = stateFile + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(jobs));
        File.Move(temporary, stateFile, true);
    }
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Keep the host alive on job-level failures.
        while (!stoppingToken.IsCancellationRequested)
        {
            Job? job = null;
            try
            {
                lock (gate)
                {
                    Cleanup();
                    job = jobs.FirstOrDefault(j => j.State == "queued");
                    if (job != null)
                    {
                        job.State = "encoding";
                        job.Cancellation = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken);
                        job.Cancellation.CancelAfter(TimeSpan.FromHours(Math.Clamp(Plugin.Instance.Configuration.MaxEncodeHours, 1, 48)));
                        Save();
                    }
                }
                if (job != null)
                {
                    var cfg = Plugin.Instance.Configuration;
                    Scratch.EnsureSpace(Scratch.ValidateRoot(job.ScratchRoot, job.Marker),
                        (long)(job.Request.SizeGB * Rules.GB * 2.3), Math.Clamp(cfg.ReserveGB, 1, 1000) * Rules.GB);
                    var running = encoding.Encode(job, p => { lock (gate) job.Progress = p; }, job.Cancellation!.Token);
                    while (!running.IsCompleted)
                    {
                        await Task.WhenAny(running, Task.Delay(TimeSpan.FromSeconds(2), CancellationToken.None));
                        if (running.IsCompleted) break;
                        try
                        {
                            var root = Scratch.ValidateRoot(job.ScratchRoot, job.Marker);
                            Scratch.EnsureSpace(root, 0, Math.Clamp(cfg.ReserveGB, 1, 1000) * Rules.GB);
                            var partial = Path.Combine(Scratch.DirectoryFor(job), "encoding.mp4");
                            if (File.Exists(partial) && new FileInfo(partial).Length > job.Request.SizeGB * Rules.GB * 1.15)
                                throw new IOException("Output exceeded its reservation.");
                        }
                        catch { job.Cancellation.Cancel(); }
                    }
                    await running;
                    lock (gate)
                    {
                        job.State = "ready";
                        job.Progress = 100;
                        job.ExpiresAt = DateTimeOffset.UtcNow.AddHours(Math.Clamp(cfg.RetentionHours, 1, 168));
                        Save();
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Portable Downloads job/cleanup failed");
                if (job != null) lock (gate)
                {
                    job.State = ex is OperationCanceledException ? "cancelled" : "failed";
                    job.Error = ex is OperationCanceledException
                        ? "Cancelled, timed out, or scratch storage became unavailable."
                        : ex is ArgumentException or IOException ? ex.Message : "Encoding failed; check server logs.";
                    try { Scratch.Delete(job); } catch (Exception cleanup) { logger.LogWarning(cleanup, "Deferred scratch cleanup"); }
                    try { Save(); } catch (Exception save) { logger.LogError(save, "Could not persist job state"); }
                }
            }
            finally
            {
                if (job != null) lock (gate) { job.Cancellation?.Dispose(); job.Cancellation = null; }
            }
            try { await Task.Delay(job == null ? 3000 : 100, stoppingToken); } catch (OperationCanceledException) { break; }
        }
    }
    private void Cleanup()
    {
        var changed = false;
        foreach (var job in jobs.ToArray())
        {
            if (job.ActiveDownloads > 0 || job.State is "queued" or "encoding") continue;
            if (job.State == "ready" && job.ExpiresAt > DateTimeOffset.UtcNow) continue;
            try
            {
                Scratch.Delete(job);
                if (job.State == "ready") { job.State = "expired"; changed = true; }
                if (job.CreatedAt < DateTimeOffset.UtcNow.AddDays(-8)) { jobs.Remove(job); changed = true; }
            }
            catch (IOException) { /* Missing scratch volume: retry later, never touch another path. */ }
        }
        PruneTickets();
        if (changed) Save();
    }
}

internal sealed class LeasedFileStream(string path, Action release)
    : FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 65536, FileOptions.Asynchronous)
{
    protected override void Dispose(bool disposing)
    {
        try { base.Dispose(disposing); } finally { release(); }
    }
    public override async ValueTask DisposeAsync()
    {
        try { await base.DisposeAsync(); } finally { release(); }
    }
}
