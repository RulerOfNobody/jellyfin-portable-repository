using System.Diagnostics;
using System.Globalization;
using System.Text.RegularExpressions;
using MediaBrowser.Common.Configuration;
using MediaBrowser.Controller.Configuration;
using MediaBrowser.Controller.MediaEncoding;
using MediaBrowser.Model.Configuration;
using MediaBrowser.Model.Dlna;
using MediaBrowser.Model.Entities;
using MediaBrowser.Model.Session;
using Microsoft.Extensions.Logging;

namespace Jellyfin.Plugin.Portable;

public sealed class EncodingService(MediaAccess access, IServerConfigurationManager config,
    IMediaEncoder encoder, EncodingHelper helper, ILogger<EncodingService> logger)
{
    public object Settings()
    {
        var options = config.GetEncodingOptions();
        return new
        {
            backend = options.HardwareAccelerationType.ToString(),
            hardwareEncoding = options.EnableHardwareEncoding,
            hevc = options.AllowHevcEncoding, av1 = options.AllowAv1Encoding,
            retentionHours = Math.Clamp(Plugin.Instance.Configuration.RetentionHours, 1, 168),
            maxBatch = Math.Clamp(Plugin.Instance.Configuration.MaxJobsPerUser, 1, 100)
        };
    }

    public (EncodingJobInfo State, EncodingOptions Options, string Encoder) Plan(Guid userId, DownloadRequest request, string output)
    {
        Rules.Validate(request);
        var (_, source) = access.Get(userId, request.ItemId);
        var options = config.GetEncodingOptions();
        if ((request.Codec == "hevc" && !options.AllowHevcEncoding) || (request.Codec == "av1" && !options.AllowAv1Encoding))
            throw new ArgumentException("Enable this codec in Jellyfin Dashboard > Playback > Transcoding first.");
        if (request.AudioIndex.HasValue && !source.MediaStreams.Any(s => s.Type == MediaStreamType.Audio && s.Index == request.AudioIndex))
            throw new ArgumentException("Selected audio track does not exist.");
        if (request.SubtitleIndex.HasValue && !source.MediaStreams.Any(s => s.Type == MediaStreamType.Subtitle
            && s.Index == request.SubtitleIndex && s.IsTextSubtitleStream && !s.IsExternal))
            throw new ArgumentException("Only embedded text subtitles can be included in this release.");
        // Reject paths whose quoting cannot be safely represented by Jellyfin's argument builder.
        if (source.Path.IndexOfAny(['"', '\r', '\n']) >= 0)
            throw new ArgumentException("The source filename contains characters unsupported by the encoder.");
        var rate = Rules.VideoBitrate(request.SizeGB, source.RunTimeTicks!.Value / (double)TimeSpan.TicksPerSecond);
        var state = new EncodingJobInfo(TranscodingJobType.Progressive)
        {
            BaseRequest = new BaseEncodingJobOptions
            {
                Id = request.ItemId, Container = "mp4", Context = EncodingContext.Static,
                VideoCodec = request.Codec, AudioCodec = "aac", AudioBitRate = 192_000,
                AudioChannels = 2, MaxAudioChannels = 2, VideoBitRate = rate,
                MaxWidth = request.Height * 16 / 9, MaxHeight = request.Height,
                MaxVideoBitDepth = 8, VideoRangeType = "SDR", RequireNonAnamorphic = true,
                EnableAutoStreamCopy = false, AllowVideoStreamCopy = false, AllowAudioStreamCopy = false,
                AudioStreamIndex = request.AudioIndex, SubtitleStreamIndex = request.SubtitleIndex ?? -1,
                SubtitleMethod = SubtitleDeliveryMethod.Embed, SubtitleCodec = "mov_text"
            },
            OutputContainer = "mp4", OutputFilePath = output, IsVideoRequest = true, IsInputVideo = true,
            VideoType = VideoType.VideoFile, OutputVideoCodec = request.Codec, OutputAudioCodec = "aac",
            OutputVideoBitrate = rate, OutputAudioBitrate = 192_000, OutputAudioChannels = 2,
            SupportedVideoCodecs = [request.Codec], SupportedAudioCodecs = ["aac"],
            SupportedSubtitleCodecs = ["mov_text"]
        };
        helper.AttachMediaSourceInfo(state, options, source, "download.mp4");
        var selectedEncoder = helper.GetVideoEncoder(state, options);
        Rules.CheckHardware(options.HardwareAccelerationType.ToString(), options.EnableHardwareEncoding, selectedEncoder);
        if (!encoder.SupportsEncoder(selectedEncoder))
            throw new ArgumentException("The Jellyfin FFmpeg installation does not support " + selectedEncoder);
        var hdr = state.VideoStream?.ColorTransfer is "smpte2084" or "arib-std-b67";
        if (hdr && !(options.EnableTonemapping || options.EnableVppTonemapping || options.EnableVideoToolboxTonemapping))
            throw new ArgumentException("This source is HDR. Enable and test HDR-to-SDR tone mapping in Jellyfin before preparing mobile copies.");
        return (state, options, selectedEncoder);
    }

    public async Task Encode(Job job, Action<double> progress, CancellationToken ct)
    {
        var dir = Scratch.DirectoryFor(job);
        Directory.CreateDirectory(dir);
        Scratch.RejectLinks(dir);
        var partial = Path.Combine(dir, "encoding.mp4");
        var (state, options, selectedEncoder) = Plan(job.UserId, job.Request, partial);
        job.Encoder = selectedEncoder;
        var args = helper.GetProgressiveVideoFullCommandLine(state, options, EncoderPreset.medium);
        // Jellyfin's streaming presets may include CRF. A size budget needs bitrate control.
        args = Regex.Replace(args, @"(?<!\S)-crf\s+\S+", "");
        var tail = "-y \"" + partial + "\"";
        if (!args.EndsWith(tail, StringComparison.Ordinal)) throw new InvalidOperationException("Unsupported Jellyfin command layout.");
        var rate = state.OutputVideoBitrate!.Value.ToString(CultureInfo.InvariantCulture);
        args = args[..^tail.Length] + $"-b:v {rate} -movflags +faststart -progress pipe:1 -nostats {tail}";
        using var process = new Process
        {
            StartInfo = new ProcessStartInfo(encoder.EncoderPath, args)
            {
                UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true,
                CreateNoWindow = true, WorkingDirectory = dir
            }
        };
        logger.LogInformation("Portable job {JobId} uses Jellyfin encoder {Encoder} ({Backend})", job.Id, selectedEncoder, options.HardwareAccelerationType);
        if (!process.Start()) throw new IOException("Could not start Jellyfin FFmpeg.");
        using var registration = ct.Register(() => { try { if (!process.HasExited) process.Kill(true); } catch (InvalidOperationException) { } });
        var stderr = new Queue<string>();
        var errors = Task.Run(async () =>
        {
            while (await process.StandardError.ReadLineAsync() is { } line)
            {
                if (stderr.Count == 30) stderr.Dequeue();
                stderr.Enqueue(line);
            }
        });
        var output = Task.Run(async () =>
        {
            while (await process.StandardOutput.ReadLineAsync() is { } line)
            {
                if (line.StartsWith("out_time_us=", StringComparison.Ordinal) &&
                    double.TryParse(line.AsSpan(12), CultureInfo.InvariantCulture, out var micros))
                    progress(Math.Clamp(micros * 10 / state.RunTimeTicks!.Value * 100, 0, 99.9));
            }
        });
        await process.WaitForExitAsync(CancellationToken.None);
        await Task.WhenAll(errors, output);
        ct.ThrowIfCancellationRequested();
        if (process.ExitCode != 0)
        {
            // Paths in raw FFmpeg output are server logs only, never returned to unprivileged clients.
            logger.LogWarning("Portable job {JobId} failed: {Tail}", job.Id, string.Join("\n", stderr));
            throw new IOException("FFmpeg failed. Check the Jellyfin server log and hardware/codec configuration. No CPU fallback was attempted.");
        }
        var file = new FileInfo(partial);
        if (!file.Exists || file.Length < 1024) throw new IOException("Encoder did not create a usable file.");
        if (file.Length > job.Request.SizeGB * Rules.GB * 1.10)
            throw new IOException("Output exceeded the selected size budget by more than 10%; it was not published.");
        await ValidateOutput(partial, state.RunTimeTicks!.Value, ct);
        Scratch.ValidateRoot(job.ScratchRoot, job.Marker);
        File.Move(partial, Scratch.OutputFor(job), true);
        job.Bytes = new FileInfo(Scratch.OutputFor(job)).Length;
    }

    private async Task ValidateOutput(string path, long expectedTicks, CancellationToken ct)
    {
        var probePath = Path.Combine(Path.GetDirectoryName(encoder.EncoderPath)!, OperatingSystem.IsWindows() ? "ffprobe.exe" : "ffprobe");
        var psi = new ProcessStartInfo(probePath) { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true };
        foreach (var arg in new[] { "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", path }) psi.ArgumentList.Add(arg);
        using var p = Process.Start(psi) ?? throw new IOException("Could not start Jellyfin ffprobe.");
        using var reg = ct.Register(() => { try { if (!p.HasExited) p.Kill(true); } catch (InvalidOperationException) { } });
        var textTask = p.StandardOutput.ReadToEndAsync();
        var errTask = p.StandardError.ReadToEndAsync();
        await p.WaitForExitAsync(CancellationToken.None);
        var text = await textTask;
        await errTask;
        ct.ThrowIfCancellationRequested();
        if (p.ExitCode != 0 || !double.TryParse(text.Trim(), CultureInfo.InvariantCulture, out var duration)
            || Math.Abs(duration - expectedTicks / (double)TimeSpan.TicksPerSecond) > Math.Max(3, expectedTicks / (double)TimeSpan.TicksPerSecond * .01))
            throw new IOException("Output duration validation failed; incomplete output was not published.");
    }
}
