using System.Security.Claims;
using Jellyfin.Extensions;
using Jellyfin.Data;
using Jellyfin.Database.Implementations.Enums;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Library;
using MediaBrowser.Model.Dto;
using MediaBrowser.Model.Entities;

namespace Jellyfin.Plugin.Portable;

public sealed class MediaAccess(ILibraryManager library, IUserManager users, IMediaSourceManager sources)
{
    public Guid UserId(ClaimsPrincipal principal)
    {
        if (!Guid.TryParse(principal.FindFirst("Jellyfin-UserId")?.Value, out var id))
            throw new UnauthorizedAccessException("A signed-in Jellyfin user is required; administrator API keys are not accepted.");
        return id;
    }
    public bool IsAdmin(Guid id) => users.GetUserById(id)?.HasPermission(PermissionKind.IsAdministrator) == true;
    public (BaseItem Item, MediaSourceInfo Source) Get(Guid userId, Guid itemId)
    {
        var user = users.GetUserById(userId) ?? throw new UnauthorizedAccessException();
        if (user.HasPermission(PermissionKind.IsDisabled) ||
            !user.HasPermission(PermissionKind.EnableContentDownloading) ||
            !user.HasPermission(PermissionKind.EnableMediaPlayback) ||
            !user.HasPermission(PermissionKind.EnableVideoPlaybackTranscoding))
            throw new UnauthorizedAccessException("Downloading and video transcoding must be enabled for this user.");
        var item = library.GetItemById(itemId) ?? throw new ArgumentException("Library item was not found.");
        if (item is not Video || !item.CanDownload(user) || !item.IsVisibleStandalone(user))
            throw new UnauthorizedAccessException("This video is not available to this user.");
        var source = sources.GetStaticMediaSources(item, false, user).FirstOrDefault(s =>
            s.Protocol == MediaBrowser.Model.MediaInfo.MediaProtocol.File && File.Exists(s.Path));
        if (source == null || source.VideoType != VideoType.VideoFile)
            throw new ArgumentException("Only local video files are supported; live streams, URLs and disc folders are not.");
        if (source.RunTimeTicks is not > 0) throw new ArgumentException("Scan the video in Jellyfin first: duration is missing.");
        return (item, source);
    }
    public object Describe(Guid userId, Guid itemId)
    {
        var (item, source) = Get(userId, itemId);
        return new
        {
            id = item.Id, title = item.Name, durationSeconds = source.RunTimeTicks / (double)TimeSpan.TicksPerSecond,
            audio = source.MediaStreams.Where(s => s.Type == MediaStreamType.Audio)
                .Select(s => new { index = s.Index, label = s.DisplayTitle ?? s.Language ?? s.Codec }),
            subtitles = source.MediaStreams.Where(s => s.Type == MediaStreamType.Subtitle && !s.IsExternal && s.IsTextSubtitleStream)
                .Select(s => new { index = s.Index, label = s.DisplayTitle ?? s.Language ?? s.Codec })
        };
    }
}
