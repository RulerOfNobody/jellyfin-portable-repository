#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DOTNET="${DOTNET:-dotnet}"
mkdir -p "$ROOT/dist"
for VERSION in 10.11.11 12.1.0; do
  FRAMEWORK=net9.0
  if [ "$VERSION" = "12.1.0" ]; then FRAMEWORK=net10.0; fi
  "$DOTNET" build "$ROOT/src/Jellyfin.Plugin.Portable" -c Release -p:JellyfinVersion="$VERSION" --nologo
  STAGE="$(mktemp -d)"
  cp "$ROOT/src/Jellyfin.Plugin.Portable/bin/Release/$FRAMEWORK/Jellyfin.Plugin.Portable.dll" "$STAGE/"
  cp "$ROOT/INSTALL.md" "$ROOT/LICENSE" "$STAGE/"
  (cd "$STAGE" && zip -q "$ROOT/dist/portable-downloads-0.1.0-jellyfin-$VERSION.zip" Jellyfin.Plugin.Portable.dll INSTALL.md LICENSE)
  rm -rf "$STAGE"
done
"$DOTNET" run --project "$ROOT/tests/Portable.Tests" -c Release
node --check "$ROOT/web/portable.js"
(cd "$ROOT" && zip -q -r dist/portable-downloads-web-adapter-0.1.0.zip tools/patch-web.mjs tools/portableBridge.js docs/WEB-INTEGRATION.md LICENSE)
(cd "$ROOT/dist" && sha256sum *.zip > SHA256SUMS)
echo "Installable artifacts are in $ROOT/dist"
