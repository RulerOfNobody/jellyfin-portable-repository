// Only run against a disposable, fresh local Jellyfin test instance.
// TEST_MEDIA and TEST_SCRATCH must already exist; no production server is touched.
import assert from 'node:assert/strict';
import { setTimeout as pause } from 'node:timers/promises';
const base = process.env.TEST_URL || 'http://127.0.0.1:8096';
if (!/^http:\/\/(127\.0\.0\.1|localhost):/.test(base)) throw new Error('This test is restricted to localhost.');
let token = '';
const auth = 'MediaBrowser Client="PortableTests", Device="Sandbox", DeviceId="portable-tests", Version="0.1"';
async function api(path, method = 'GET', body, expected = 200, customToken = token, extra = {}) {
    const r = await fetch(base + path, { method, headers: {
        Authorization: auth, ...(customToken ? { 'X-Emby-Token': customToken } : {}),
        ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...extra
    }, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await r.text();
    assert.equal(r.status, expected, `${method} ${path}: ${r.status} ${text.slice(0, 600)}`);
    return text ? JSON.parse(text) : null;
}
await api('/Startup/Configuration', 'POST', { UICulture: 'en-US', MetadataCountryCode: 'US', PreferredMetadataLanguage: 'en' }, 204);
await api('/Startup/User');
await api('/Startup/User', 'POST', { Name: 'portable-test-admin', Password: 'DisposableTestOnly123!' }, 204);
await api('/Startup/RemoteAccess', 'POST', { EnableRemoteAccess: false, EnableAutomaticPortMapping: false }, 204);
await api('/Startup/Complete', 'POST', undefined, 204);
const login = await api('/Users/AuthenticateByName', 'POST', { Username: 'portable-test-admin', Pw: 'DisposableTestOnly123!' });
token = login.AccessToken;
const pluginId = '9ab61945-dd21-43f9-86ec-9c1144374cac';
const cfg = await api(`/Plugins/${pluginId}/Configuration`);
Object.assign(cfg, { ScratchPath: process.env.TEST_SCRATCH, ReserveGB: 1, QuotaGB: 5, RetentionHours: 1 });
await api(`/Plugins/${pluginId}/Configuration`, 'POST', cfg, 204);
await api('/PortableDownloads/storage/test', 'POST');
console.log('PASS plugin loaded and scratch test passed');
await api('/PortableDownloads/jobs', 'GET', undefined, 401, '');
console.log('PASS anonymous access denied');
await api('/Library/VirtualFolders?name=PortableTests&collectionType=movies&refreshLibrary=true', 'POST',
    { LibraryOptions: { PathInfos: [{ Path: process.env.TEST_MEDIA }], EnableRealtimeMonitor: false,
        MetadataSavers: [], DisabledLocalMetadataReaders: [], LocalMetadataReaderOrder: [],
        TypeOptions: [{ Type: 'Movie', MetadataFetchers: [], ImageFetchers: [] }] } }, 204);
let items;
for (let i = 0; i < 45; i++) {
    items = await api(`/Items?userId=${login.User.Id}&Recursive=true&IncludeItemTypes=Movie&Fields=MediaSources`);
    if (items.Items.some(x => x.RunTimeTicks > 0)) break;
    await pause(1000);
}
const item = items.Items.find(x => x.RunTimeTicks > 0);
assert.ok(item, 'Test media scanned');
const described = await api(`/PortableDownloads/items/${item.Id}`);
assert.ok(described.durationSeconds > 0);
await api('/PortableDownloads/jobs', 'POST', [{ itemId: item.Id, sizeGB: 0, codec: 'h264' }], 400);
console.log('PASS metadata and request validation');
const [job] = await api('/PortableDownloads/jobs', 'POST', [{ itemId: item.Id, sizeGB: .25, codec: 'h264', height: 720 }]);
let final;
for (let i = 0; i < 90; i++) {
    final = (await api('/PortableDownloads/jobs')).find(x => x.id === job.id);
    if (['ready', 'failed', 'cancelled'].includes(final.state)) break;
    await pause(1000);
}
assert.equal(final.state, 'ready', JSON.stringify(final));
assert.ok(final.bytes > 1024);
console.log('PASS actual FFmpeg encode and output validation', final.encoder, final.bytes);
const ticket = await api(`/PortableDownloads/jobs/${job.id}/ticket`, 'POST');
const ranged = await fetch(base + `/PortableDownloads/jobs/${job.id}/file?ticket=${ticket.ticket}`, { headers: { Range: 'bytes=0-1023' } });
assert.equal(ranged.status, 206);
assert.equal((await ranged.arrayBuffer()).byteLength, 1024);
await api(`/PortableDownloads/jobs/${job.id}/file?ticket=wrong`, 'GET', undefined, 403, '');
console.log('PASS resumable download and invalid ticket rejection');
const second = await api('/Users/New', 'POST', { Name: 'restricted-test-user' });
await api(`/Users/${second.Id}/Password`, 'POST', { CurrentPw: '', NewPw: 'AnotherTestOnly123!' }, 204);
const secondLogin = await api('/Users/AuthenticateByName', 'POST', { Username: 'restricted-test-user', Pw: 'AnotherTestOnly123!' });
await api(`/PortableDownloads/jobs/${job.id}/ticket`, 'POST', undefined, 403, secondLogin.AccessToken);
await api('/PortableDownloads/storage/test', 'POST', undefined, 403, secondLogin.AccessToken);
console.log('PASS cross-user isolation and admin-only storage test');
const policyUser = await api(`/Users/${second.Id}`);
policyUser.Policy.EnableContentDownloading = false;
await api(`/Users/${second.Id}/Policy`, 'POST', policyUser.Policy, 204);
await api(`/PortableDownloads/items/${item.Id}`, 'GET', undefined, 403, secondLogin.AccessToken);
console.log('PASS Jellyfin download permission enforcement');
await api(`/PortableDownloads/jobs/${job.id}`, 'DELETE', undefined, 204);
assert.equal((await api('/PortableDownloads/jobs')).find(x => x.id === job.id).state, 'cancelled');
console.log('PASS completed-file deletion');
const encConfig = await api('/System/Configuration/encoding');
Object.assign(encConfig, { AllowHevcEncoding: true, AllowAv1Encoding: true });
await api('/System/Configuration/encoding', 'POST', encConfig, 204);
for (const codec of ['hevc', 'av1']) {
    const [encoded] = await api('/PortableDownloads/jobs', 'POST', [{ itemId: item.Id, sizeGB: .25, codec, height: 480 }]);
    let output;
    for (let i = 0; i < 120; i++) {
        output = (await api('/PortableDownloads/jobs')).find(x => x.id === encoded.id);
        if (['ready', 'failed', 'cancelled'].includes(output.state)) break;
        await pause(1000);
    }
    assert.equal(output.state, 'ready', JSON.stringify(output));
    console.log(`PASS actual ${codec} encode`, output.encoder, output.bytes);
    await api(`/PortableDownloads/jobs/${encoded.id}`, 'DELETE', undefined, 204);
}
console.log('Integration tests passed.');
