using Jellyfin.Plugin.Portable;

var passed = 0;
void Test(string name, Action action) { action(); Console.WriteLine("PASS " + name); passed++; }
void Reject(Action action) { try { action(); } catch (Exception e) when (e is ArgumentException or IOException) { return; } throw new Exception("Expected rejection."); }
void Check(bool value) { if (!value) throw new Exception("Assertion failed."); }
var id = Guid.NewGuid();
Test("Valid movie request", () => Rules.Validate(new(id)));
Test("Per-episode small size", () => Rules.Validate(new(id, .25, "hevc", 720)));
Test("AV1 accepted as a codec", () => Rules.Validate(new(id, 1, "av1")));
Test("Empty item ID rejected", () => Reject(() => Rules.Validate(new(Guid.Empty))));
Test("Negative size rejected", () => Reject(() => Rules.Validate(new(id, -1))));
Test("NaN rejected", () => Reject(() => Rules.Validate(new(id, double.NaN))));
Test("Infinity rejected", () => Reject(() => Rules.Validate(new(id, double.PositiveInfinity))));
Test("Huge size rejected", () => Reject(() => Rules.Validate(new(id, 21))));
Test("Unknown codec rejected", () => Reject(() => Rules.Validate(new(id, 6, "h264;rm -rf /"))));
Test("Unsupported resolution rejected", () => Reject(() => Rules.Validate(new(id, Height: 4000))));
Test("Invalid stream rejected", () => Reject(() => Rules.Validate(new(id, AudioIndex: -1))));
Test("Two hour 6GB bitrate calculation", () => Check(Rules.VideoBitrate(6, 7200) == 6_274_666));
Test("Unknown duration rejected", () => Reject(() => Rules.VideoBitrate(6, 0)));
Test("Impossibly small bitrate rejected", () => Reject(() => Rules.VideoBitrate(.25, 100000)));
Test("Excessive bitrate capped", () => Check(Rules.VideoBitrate(20, 60) == 40_000_000));
Test("QSV hardware selected", () => Rules.CheckHardware("qsv", true, "hevc_qsv"));
Test("NVENC hardware selected", () => Rules.CheckHardware("nvenc", true, "av1_nvenc"));
Test("VAAPI hardware selected", () => Rules.CheckHardware("vaapi", true, "h264_vaapi"));
Test("QSV to CPU fallback rejected", () => Reject(() => Rules.CheckHardware("qsv", true, "libsvtav1")));
Test("Disabled hardware permits CPU", () => Rules.CheckHardware("qsv", false, "libx264"));
Test("Software server permits CPU", () => Rules.CheckHardware("none", true, "libx265"));
var root = Path.Combine(Path.GetTempPath(), "portable-tests-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(root);
try
{
    Test("Missing marker fails closed", () => Reject(() => Scratch.ValidateRoot(root, "test")));
    File.WriteAllText(Path.Combine(root, ".portable-downloads-volume"), "test\n");
    Test("Matching marker accepted", () => Check(Scratch.ValidateRoot(root, "test") == root));
    Test("Wrong marker rejected", () => Reject(() => Scratch.ValidateRoot(root, "other")));
    Test("Filesystem root rejected", () => Reject(() => Scratch.ValidateRoot(Path.GetPathRoot(root)!, "test")));
    Test("Relative path rejected", () => Reject(() => Scratch.ValidateRoot("relative", "test")));
    var job = new Job { Id = id, ScratchRoot = root, Marker = "test" };
    var dir = Scratch.DirectoryFor(job); Directory.CreateDirectory(dir);
    var original = Path.Combine(root, "original.mkv"); File.WriteAllText(original, "source");
    File.WriteAllText(Path.Combine(dir, "download.mp4"), "output");
    Test("Cleanup never touches original", () => { Scratch.Delete(job); Check(File.Exists(original)); Check(!Directory.Exists(dir)); });
    Directory.CreateDirectory(dir); File.WriteAllText(Path.Combine(dir, "unexpected.txt"), "do not delete");
    Test("Unexpected contents stop cleanup", () => Reject(() => Scratch.Delete(job)));
    Directory.Delete(dir, true);
    if (!OperatingSystem.IsWindows())
    {
        var link = Path.Combine(root, "link"); Directory.CreateSymbolicLink(link, root);
        Test("Symlink scratch directory rejected", () => Reject(() => Scratch.ValidateRoot(link, "test")));
        Directory.Delete(link);
        Directory.CreateDirectory(dir); File.CreateSymbolicLink(Path.Combine(dir, "download.mp4"), original);
        Test("Symlink output cleanup rejected", () => Reject(() => Scratch.Delete(job)));
        File.Delete(Path.Combine(dir, "download.mp4")); Directory.Delete(dir);
    }
    File.Delete(Path.Combine(root, ".portable-downloads-volume"));
    Test("Disappearing marker stops cleanup", () => Reject(() => Scratch.Delete(job)));
}
finally { Directory.Delete(root, true); }
Console.WriteLine($"{passed} tests passed.");
