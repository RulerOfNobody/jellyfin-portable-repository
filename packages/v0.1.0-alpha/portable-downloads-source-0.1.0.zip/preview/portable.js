/* Portable Downloads: no external dependencies, no persisted credentials. */
(function () {
    'use strict';
    if (window.PortableDownloads) return;
    let host, root, dialog, api, cssUrl, pollTimer, media = [], settings, tab = 'prepare';
    let busy = false, opening = false, lastFocus;
    const el = (tag, text, cls) => {
        const node = document.createElement(tag);
        if (text != null) node.textContent = text;
        if (cls) node.className = cls;
        return node;
    };
    function setup() {
        if (host) return;
        host = document.createElement('portable-downloads');
        host.dataset.theme = 'dark';
        root = host.attachShadow({ mode: 'open' });
        root.innerHTML = `
          <link rel="stylesheet">
          <button class="toolbar" type="button">Offline downloads</button>
          <dialog aria-labelledby="pd-heading">
            <header><div class="brand">
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-label="Portable Downloads">
                <path d="M9 3h14v26H9zM13 23h6M13 9l8 5-8 5V9z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
              </svg><div><h1 id="pd-heading">Take it with you</h1><p class="muted">Portable Downloads</p></div>
            </div><div><button class="quiet theme" type="button" aria-label="Switch color theme">Theme</button>
            <button class="quiet close" type="button" aria-label="Close download options">×</button></div></header>
            <nav class="tabs" aria-label="Download views">
              <button type="button" data-tab="prepare" aria-selected="true">Prepare download</button>
              <button type="button" data-tab="queue" aria-selected="false">Your downloads</button>
            </nav>
            <div class="content">
              <p class="status" role="alert"></p>
              <section class="prepare">
                <div class="grid">
                  <label>Video format<select class="codec">
                    <option value="h264">H.264 · most compatible</option>
                    <option value="hevc">HEVC / H.265 · space saver</option>
                    <option value="av1">AV1 · compatible devices only</option>
                  </select></label>
                  <label>Resolution ceiling<select class="height">
                    <option value="1080">1080p</option><option value="720">720p</option><option value="480">480p</option>
                  </select></label>
                </div>
                <p class="notice backend"></p>
                <div class="episodes"></div>
                <p class="muted">Size is a budget, not a quality guarantee. Actual output may be smaller or vary by up to 10%. GB uses decimal units.</p>
                <p class="muted retention"></p>
              </section>
              <section class="queue" hidden><div class="jobs"></div><button type="button" class="refresh quiet">Refresh status</button></section>
            </div>
            <footer><div><div class="total"></div><small class="footnote">MP4 · AAC stereo · original untouched</small></div>
              <button class="primary submit" type="button">Prepare download</button></footer>
          </dialog>`;
        root.querySelector('link').href = cssUrl;
        dialog = root.querySelector('dialog');
        root.querySelector('.close').onclick = () => dialog.close();
        root.querySelector('.theme').onclick = () => host.dataset.theme = host.dataset.theme === 'dark' ? 'light' : 'dark';
        root.querySelector('.toolbar').onclick = () => showQueue();
        root.querySelectorAll('[data-tab]').forEach(button => button.onclick = () => switchTab(button.dataset.tab));
        root.querySelector('.refresh').onclick = refreshJobs;
        root.querySelector('.submit').onclick = submit;
        root.querySelector('.codec').onchange = updateBackend;
        dialog.addEventListener('close', () => { clearInterval(pollTimer); lastFocus?.focus(); });
        document.body.append(host);
    }
    function error(message = '') { root.querySelector('.status').textContent = message; }
    function updateTotal() {
        const total = media.reduce((sum, m) => sum + m.sizeGB, 0);
        root.querySelector('.total').textContent = media.length
            ? `${total.toFixed(2).replace(/\.00$/, '')} GB budget${media.length > 1 ? ` · ${media.length} files` : ''}` : '';
        root.querySelector('.submit').disabled = busy || !media.length;
    }
    function updateBackend() {
        const codec = root.querySelector('.codec').value;
        const description = settings?.hardwareEncoding && settings.backend !== 'none'
            ? `Jellyfin ${settings.backend.toUpperCase()} · uses your configured device. No silent CPU fallback.`
            : 'Jellyfin software encoding · follows the server configuration.';
        root.querySelector('.backend').textContent = description + (codec === 'av1'
            ? ' AV1 playback depends on the phone and player. Check compatibility before a long trip.'
            : codec === 'hevc' ? ' HEVC playback requires a compatible phone and player.' : '');
    }
    function trackSelect(labelText, tracks, none, id) {
        const label = el('label', labelText);
        const select = el('select');
        select.id = id;
        label.htmlFor = id;
        select.append(new Option(none, ''));
        for (const track of tracks || []) select.append(new Option(track.label, String(track.index)));
        label.append(select);
        return { label, select };
    }
    function renderMedia() {
        const list = root.querySelector('.episodes');
        list.replaceChildren();
        media.forEach((m, i) => {
            const row = el('article', null, 'episode');
            const top = el('div', null, 'episode-top');
            const info = el('div');
            info.append(el('h2', m.title), el('small', `${Math.max(1, Math.round(m.durationSeconds / 60))} min · ${media.length > 1 ? 'size for this episode' : 'size for this file'}`));
            const label = el('label', 'Target GB');
            const number = el('input', null, 'size');
            number.type = 'number'; number.min = '.25'; number.max = '20'; number.step = '.25';
            number.value = m.sizeGB; number.id = `pd-size-${i}`; label.htmlFor = number.id; label.append(number);
            top.append(info, label);
            const slider = el('input'); slider.type = 'range'; slider.min = '.25'; slider.max = '20'; slider.step = '.25';
            slider.value = m.sizeGB; slider.setAttribute('aria-label', `Size for ${m.title}`);
            function change(value) {
                if (!Number.isFinite(value) || value < .25 || value > 20) return;
                m.sizeGB = value; slider.value = value; number.value = value; updateTotal();
            }
            slider.oninput = () => change(Number(slider.value));
            number.onchange = () => { change(Number(number.value)); number.value = m.sizeGB; };
            const endpoints = el('div', null, 'range-label');
            endpoints.append(el('span', '0.25 GB'), el('span', '20 GB'));
            const details = el('details'); details.append(el('summary', 'Audio and subtitles'));
            const tracks = el('div', null, 'grid');
            const audio = trackSelect('Audio track', m.audio, 'Default audio', `pd-audio-${i}`);
            const sub = trackSelect('Text subtitles', m.subtitles, 'No subtitles', `pd-sub-${i}`);
            audio.select.onchange = () => m.audioIndex = audio.select.value === '' ? null : Number(audio.select.value);
            sub.select.onchange = () => m.subtitleIndex = sub.select.value === '' ? null : Number(sub.select.value);
            tracks.append(audio.label, sub.label); details.append(tracks, el('small', 'Embedded text tracks only. Image and external subtitles are not supported in this release.'));
            row.append(top, slider, endpoints, details); list.append(row);
        });
        updateTotal();
    }
    function switchTab(value) {
        tab = value; error();
        root.querySelector('.prepare').hidden = value !== 'prepare';
        root.querySelector('.queue').hidden = value !== 'queue';
        root.querySelector('footer').hidden = value !== 'prepare';
        root.querySelectorAll('[data-tab]').forEach(b => b.setAttribute('aria-selected', String(b.dataset.tab === value)));
        clearInterval(pollTimer);
        if (value === 'queue') { refreshJobs(); pollTimer = setInterval(refreshJobs, 3000); }
    }
    async function refreshJobs() {
        try {
            const jobs = await api.request('jobs');
            const list = root.querySelector('.jobs');
            list.replaceChildren();
            if (!jobs.length) {
                const empty = el('div', null, 'empty');
                empty.append(el('h2', 'Nothing to carry yet'), el('p', 'Choose Download on a movie or episode to prepare a smaller copy.', 'muted'));
                list.append(empty);
            }
            for (const job of jobs) {
                const row = el('article', null, 'job');
                const head = el('div', null, 'job-head');
                head.append(el('h2', job.title), el('span', job.state, 'muted')); row.append(head);
                row.append(el('small', `${job.codec.toUpperCase()} · ${job.height}p · ${job.bytes ? (job.bytes / 1e9).toFixed(2) + ' GB actual' : job.sizeGB + ' GB budget'}${job.encoder ? ' · ' + job.encoder : ''}`));
                if (job.state === 'encoding') {
                    const progress = el('progress'); progress.max = 100; progress.value = job.progress;
                    progress.setAttribute('aria-label', `${job.title} encoding progress`);
                    row.append(progress, el('small', `${job.progress.toFixed(1)}%`));
                }
                if (job.error) row.append(el('p', job.error, 'status'));
                if (job.expiresAt && job.state === 'ready') row.append(el('p', `Expires ${new Date(job.expiresAt).toLocaleString()}`, 'muted'));
                const actions = el('div', null, 'job-actions');
                if (job.state === 'ready') {
                    const button = el('button', 'Download file', 'primary'); button.type = 'button';
                    button.onclick = async () => {
                        button.disabled = true;
                        try {
                            const result = await api.request(`jobs/${job.id}/ticket`, { method: 'POST' });
                            api.download(job.id, result.ticket);
                        } catch (e) { error(e.message); } finally { button.disabled = false; }
                    };
                    actions.append(button);
                }
                if (['queued', 'encoding', 'ready'].includes(job.state)) {
                    const cancel = el('button', job.state === 'ready' ? 'Delete server copy' : 'Cancel', 'quiet');
                    cancel.type = 'button'; cancel.onclick = async () => {
                        if (job.state === 'ready' && !window.confirm('Delete this temporary server copy? Your downloaded file and original media will not be deleted.')) return;
                        try { await api.request(`jobs/${job.id}`, { method: 'DELETE' }); await refreshJobs(); } catch (e) { error(e.message); }
                    };
                    actions.append(cancel);
                }
                row.append(actions); list.append(row);
            }
        } catch (e) { error(e.message); }
    }
    async function submit() {
        if (busy || !media.length) return;
        busy = true; error(); updateTotal();
        root.querySelector('.submit').textContent = 'Adding to queue…';
        try {
            const requests = media.map(m => ({
                itemId: m.id, sizeGB: m.sizeGB, codec: root.querySelector('.codec').value,
                height: Number(root.querySelector('.height').value), audioIndex: m.audioIndex ?? null,
                subtitleIndex: m.subtitleIndex ?? null
            }));
            await api.request('jobs', { method: 'POST', body: requests });
            switchTab('queue');
        } catch (e) { error(e.message); }
        finally { busy = false; root.querySelector('.submit').textContent = 'Prepare download'; updateTotal(); }
    }
    function show() {
        lastFocus = document.activeElement;
        if (!dialog.open) dialog.showModal();
    }
    function showQueue() { show(); switchTab('queue'); }
    window.PortableDownloads = {
        async open(items, adapter, styleUrl) {
            if (busy || opening) return;
            opening = true;
            api = adapter; cssUrl = styleUrl; setup(); show(); switchTab('prepare'); error('Loading download options…');
            media = []; renderMedia();
            try {
                settings = await api.request('settings');
                const videos = items.filter(i => i.itemId);
                if (videos.length > settings.maxBatch) throw new Error(`Select ${settings.maxBatch} or fewer videos at a time.`);
                // Bound simultaneous API calls for large episode batches.
                for (let i = 0; i < videos.length; i += 4) {
                    const batch = await Promise.all(videos.slice(i, i + 4).map(v => api.request(`items/${v.itemId}`)));
                    media.push(...batch.map(m => ({ ...m, sizeGB: m.durationSeconds < 4000 ? 1.5 : 6 })));
                }
                root.querySelector('option[value=hevc]').disabled = !settings.hevc;
                root.querySelector('option[value=av1]').disabled = !settings.av1;
                if (root.querySelector('.codec').selectedOptions[0].disabled) root.querySelector('.codec').value = 'h264';
                root.querySelector('.retention').textContent = `Server copies expire ${settings.retentionHours} ${settings.retentionHours === 1 ? 'hour' : 'hours'} after encoding finishes. Downloads stay on your device.`;
                updateBackend(); renderMedia(); error();
                if (!media.length) { switchTab('queue'); }
            } catch (e) { error(e.message); }
            finally { opening = false; }
        }
    };
})();
