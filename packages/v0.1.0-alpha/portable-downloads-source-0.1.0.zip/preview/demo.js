const ids = ['11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333'];
let episodeMode = false;
const demoJobs = [];
const adapter = {
    async request(path, options = {}) {
        await new Promise(r => setTimeout(r, 120));
        if (path === 'settings') return { backend: 'qsv', hardwareEncoding: true, hevc: true, av1: true, retentionHours: 24, maxBatch: 20 };
        if (path.startsWith('items/')) {
            const id = path.split('/')[1];
            return { id, title: episodeMode ? `The Long Way Home · Episode ${ids.indexOf(id) + 1}` : 'The Long Way Home',
                durationSeconds: episodeMode ? 2700 : 7200,
                audio: [{ index: 1, label: 'English · original audio' }, { index: 2, label: 'Spanish' }],
                subtitles: [{ index: 3, label: 'English' }] };
        }
        if (path === 'jobs' && options.method === 'POST') {
            demoJobs.push(...options.body.map((r, i) => ({ ...r, id: crypto.randomUUID(), title: episodeMode ? `Episode ${i + 1}` : 'The Long Way Home',
                state: 'queued', progress: 0, started: Date.now(), encoder: r.codec + '_qsv' })));
            return demoJobs;
        }
        if (path === 'jobs') {
            demoJobs.forEach(j => {
                if (j.state === 'cancelled') return;
                j.progress = Math.min(100, (Date.now() - j.started) / 120);
                j.state = j.progress >= 100 ? 'ready' : j.progress > 10 ? 'encoding' : 'queued';
                if (j.state === 'ready') { j.bytes = j.sizeGB * 1e9 * .96; j.expiresAt = new Date(Date.now() + 86400000).toISOString(); }
            });
            return demoJobs;
        }
        if (options.method === 'DELETE') { demoJobs.find(j => j.id === path.split('/')[1]).state = 'cancelled'; return; }
        if (path.endsWith('/ticket')) return { ticket: 'preview-only' };
        throw new Error('Preview route not implemented.');
    },
    download() { alert('Preview only: on your server this button downloads the encoded MP4.'); }
};
document.querySelector('#movie').onclick = () => {
    episodeMode = false; window.PortableDownloads.open([{ itemId: ids[0] }], adapter, 'portable.css');
};
document.querySelector('#episodes').onclick = () => {
    episodeMode = true; window.PortableDownloads.open(ids.map(itemId => ({ itemId })), adapter, 'portable.css');
};
