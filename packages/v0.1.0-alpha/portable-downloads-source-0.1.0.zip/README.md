# Portable Downloads for Jellyfin

Prepare a phone-sized copy of a movie or episode, download it, and expire the server copy automatically. Originals are never replaced and temporary copies are not added to the library.

**Status: v0.1.0 alpha.** Installable plugin ZIPs are available on the repository's [Releases page](https://github.com/RulerOfNobody/jellyfin-portable-downloads/releases). This repository and its releases are private. Use manual plugin installation; a private GitHub URL is not an anonymously accessible Jellyfin catalog.

## What is implemented

- Mobile-friendly options dialog opened by the existing **Download** action in the included Jellyfin Web integration.
- Individual size sliders for each video in a batch, from 0.25 to 20 decimal GB. A movie defaults to 6 GB; short items default to 1.5 GB. Every request remains editable.
- H.264, HEVC, and AV1; 480p, 720p, or 1080p ceilings; audio-track selection; embedded text subtitle selection.
- MP4 output with AAC stereo; no up-front multi-GB JavaScript Blob download.
- Uses **Jellyfin's own `EncodingHelper`, current encoding configuration, and FFmpeg binary**. Backend/device selection, decoding, scaling, and tone mapping are delegated to Jellyfin. There is no independent GPU override.
- HEVC/AV1 honor Jellyfin's allow-encoding settings. If the configured hardware backend would fall back to a software encoder, the request is rejected. Hardware initialization failures are reported, not silently retried on the CPU.
- One active encode at a time, persistent job metadata, per-user/server queue limits, quotas, free-space checks, cancellation, timeouts, progress, and duration validation.
- Temporary storage chosen by the administrator, protected by a volume marker. Completed outputs expire 24 hours after encoding by default. Cleanup defers active downloads.
- Jellyfin user/library/download/transcoding permissions, job ownership, scoped expiring download tickets, and HTTP Range support.

## Compatibility

| Component | Status |
|---|---|
| Jellyfin Server 10.11.11 / .NET 9 | Built and exercised with a real server and FFmpeg |
| Jellyfin Web 10.11.11 | Source adapter and prebuilt adapted web client included in the first release |
| Jellyfin Server 12.1.0 / .NET 10 | Compiles; not runtime-certified in this release |
| Other server versions | Not claimed; rebuild and test against the exact version |
| Native Moonfin, Swiftfin, Android, iOS clients | Not automatically modified by a server plugin |
| Clients that actually load the adapted server-hosted web client | Candidates for compatibility; test the exact app |

The backend plugin is installable on its own, but **changing the Download menu requires the web integration**. Do not assume a DLL can rewrite native client menus or populate a native app's offline library. See [web integration](docs/WEB-INTEGRATION.md).

## Installation

See [INSTALL.md](INSTALL.md) for Unraid mappings, scratch marker setup, the private ZIP installation process, and rollback. Do not install both server-target ZIPs. Do not replace your current web client with a different-version build.

## Important limitations

- This is size-budgeted, single-pass encoding, **not exact-size two-pass encoding**. Complex content, frame rate, encoder and hardware affect quality and actual size. Outputs may be substantially smaller; outputs more than 10% over budget fail instead of being offered for download.
- Disk quota reserves 115% of requested sizes, and starting an encode requires additional workspace for MP4 faststart. This is intentionally conservative.
- Embedded text subtitles only in v0.1. Image/PGS, external subtitles and subtitle burn-in are not implemented. Unsupported tracks are not offered.
- Local ordinary video files only. No remote URLs, live streams, ISO/disc folders, multi-version source picker, or source-file stream-copy optimization.
- HDR sources require Jellyfin tone mapping to be enabled and working. Physical HDR/GPU combinations still need testing on your hardware.
- Restarted queued/encoding jobs are marked failed; they are not resumed mid-encode. Ready outputs survive restarts, but download tickets do not.
- No phone codec auto-detection. Selecting AV1 does not prove the phone/player can decode it efficiently.
- No global scheduler coordination with Jellyfin's streaming transcodes. The plugin runs at most one encode but can still compete for the GPU; cancel it if live playback suffers.
- Selecting a path is admin-only, not physical-disk management. Unraid/Docker must expose that directory first.
- An actively failing SSD is not recommended. The marker is a fail-closed mount guard, not protection against every possible disk failure or corrupt data.

## Build and test

Install .NET SDKs 9 and 10, Node.js, and `zip`, then run:

```sh
bash tools/package.sh
```

This builds both plugin packages, runs the isolated storage/rate/validation tests, and packages the web adapter. GitHub Actions does the same on pushes and pull requests.

`tests/integration.mjs` exercises a fresh disposable localhost Jellyfin server. It creates test users and a library; **never point it at production**. See [test report](docs/TESTING.md) for what was actually verified and what remains hardware-dependent.

## Design and references

The plugin follows the [official Jellyfin plugin template](https://github.com/jellyfin/jellyfin-plugin-template). Hardware command generation is delegated to Jellyfin's [EncodingHelper](https://github.com/jellyfin/jellyfin/blob/v10.11.11/MediaBrowser.Controller/MediaEncoding/EncodingHelper.cs), rather than duplicating backend/device logic. The web adapter patches the shared [fileDownloader handler](https://github.com/jellyfin/jellyfin-web/blob/v10.11.11/src/scripts/fileDownloader.js).

Jellyfin's [container documentation](https://jellyfin.org/docs/general/installation/container/) explains host-to-container mappings. Its [transcoding documentation](https://jellyfin.org/docs/general/post-install/transcoding/) covers HDR and acceleration considerations. See [FFmpeg's H.264 guide](https://trac.ffmpeg.org/wiki/Encode/H.264) for the difference between quality-based and bitrate-targeted encoding.

Licensed GPL-3.0-or-later. The separately packaged Jellyfin Web build retains Jellyfin Web's own license and notices.
