# Verification report

Release: 0.1.0 alpha. Tests were run in an isolated Linux sandbox, not on the user's Unraid server.

## Completed automated checks

- Plugin builds against Jellyfin 10.11.11 (.NET 9) and 12.1.0 (.NET 10), with zero compiler warnings/errors.
- 31 tests for request validation, decimal-GB bitrate calculation, hardware-to-software fallback rejection, marker validation, symlink rejection and constrained cleanup.
- Real Jellyfin 10.11.11 server starts and loads the DLL.
- Plugin configuration save and scratch write test pass.
- Anonymous access is rejected.
- A generated 12-second SDR H.264/AAC test video scans into a disposable library.
- Real FFmpeg H.264, HEVC and AV1 conversions complete using `libx264`, `libx265` and `libsvtav1`; ffprobe validates duration for all three.
- Output download supports HTTP 206 Range responses.
- Invalid download tickets are rejected.
- Another user's session cannot mint a ticket for the first user's job.
- Non-administrators cannot run the storage test.
- Revoking Jellyfin's content-download permission blocks access to item preparation.
- Deleting a completed job removes the temporary output and marks it cancelled.
- Patched Jellyfin Web 10.11.11 compiles successfully.

## Frontend QA inventory

- Existing video Download action opens the options dialog, not an original-file download.
- Codec and resolution controls; disabled server codecs; per-item size number/slider synchronization and combined budget.
- Batch episode sliders, audio/subtitle choices.
- Queue, progress, download-ready and cancellation states.
- Theme switch, close, Escape, reopen queue, and mobile viewport fit.
- Failed requests show an actionable error.
- Demo is labeled as simulation and does not imply a live server connection.

See release notes for final browser QA results.

The live Jellyfin Web menu was exercised in Chromium: More > Download opened the real plugin dialog; editing size/resolution, encoding, and downloading the resulting MP4 succeeded. The browser download completed without error. Mobile queue and batch dialogs were inspected at 390×844 with no horizontal overflow. The batch preview exercised independent slider/number controls, codec/resolution, audio/subtitle selection, theme switching, cancellation, Escape and queue reopening. An injected missing-scratch-marker error was displayed and the submit button remained retryable. The preview uses simulated jobs; the separate single-video browser test used the real server.

## Not certified

- Physical Intel QSV, VAAPI/AMD, NVIDIA NVENC, VideoToolbox or Rockchip hardware. The plugin delegates generation to Jellyfin's own helper; real drivers and devices still need a smoke test.
- HDR/Dolby Vision source combinations, phone-specific AV1/HEVC playback, very large multi-hour encodes, actual failing-disk behavior.
- Native Moonfin app menus/offline library.
- Runtime on Jellyfin 12.1.0; only compilation is claimed for that target.
- Exact-size encoding or consistent quality across movies. The implementation uses a single-pass bitrate budget.
- A 24-hour wall-clock soak test; retention logic is implemented but a production soak remains necessary.

## Reproduce integration tests

Create a disposable Jellyfin 10.11.11 instance with the plugin already in its plugins directory, an empty initial configuration, and FFmpeg/ffprobe installed. Generate a short video in a test media folder. Create the scratch marker as described in INSTALL.md.

```sh
TEST_URL=http://127.0.0.1:8096 \
TEST_MEDIA=/absolute/test-media \
TEST_SCRATCH=/absolute/test-scratch \
node tests/integration.mjs
```

The script configures first-run setup, creates users and a library, and exercises an encode/download/delete. It is restricted to localhost but **still must not be run against a production localhost Jellyfin instance**.
