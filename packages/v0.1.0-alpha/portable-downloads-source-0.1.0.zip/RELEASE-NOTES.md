# Portable Downloads 0.1.0 alpha

Initial private release: installable Jellyfin server plugin, adapted Jellyfin Web 10.11.11 build, reproducible web source adapter, Unraid installation guide, automated tests and CI.

## Downloads

- `portable-downloads-0.1.0-jellyfin-10.11.11.zip`: plugin DLL, install instructions and license.
- `portable-downloads-0.1.0-jellyfin-12.1.0.zip`: separately compiled target; runtime not certified yet.
- `jellyfin-web-10.11.11-portable-0.1.0.zip`: prebuilt Jellyfin Web with the Download-dialog adapter. Use only with the matching version.
- `portable-downloads-web-adapter-0.1.0.zip`: source patch tool and adapter for reproducible builds.
- `SHA256SUMS`: checksums for release ZIPs.

## Verified

Both plugin targets compile without warnings. All 31 isolated validation/storage tests pass. A real Jellyfin 10.11.11 instance loaded the final plugin binary and encoded a generated SDR video in **H.264, HEVC and AV1** with FFmpeg. It validated the outputs, served a resumable HTTP Range download, enforced Jellyfin download permissions, rejected unauthorized/cross-user requests and deleted temporary output. The adapted web build compiles.

Browser testing on the real adapted Jellyfin Web confirmed **More > Download** opens the options dialog. Changing the size/resolution, queuing a real encode and downloading the completed MP4 through the browser all succeeded. Mobile layouts, independent episode sliders, theme switching, simulated cancellation and error states were also tested.

## Read before installing

This is an alpha, not a production-certified release. Hardware device selection is inherited through Jellyfin's encoding helper, but physical GPU/driver combinations still need validation on the intended Unraid host. The plugin will not silently fall back to software when hardware encoding is configured.

Size is an approximate bitrate budget, not exact two-pass sizing. Only embedded text subtitles are supported. Native Moonfin/mobile menus and native offline libraries are not patched by this release.

The repository is private, so install the downloaded ZIP manually. An ordinary private GitHub URL will not work as an anonymous Jellyfin plugin catalog. See INSTALL.md for full installation and rollback instructions.
