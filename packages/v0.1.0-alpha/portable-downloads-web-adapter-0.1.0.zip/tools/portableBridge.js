/* Runs inside Jellyfin Web's build, using the same API session and selected server. */
import { ServerConnections } from 'lib/jellyfin-apiclient';

let loading;
function load(url) {
    if (window.PortableDownloads) return Promise.resolve();
    if (!loading) loading = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = url;
        script.onload = resolve;
        script.onerror = () => { script.remove(); loading = null; reject(new Error('Portable Downloads plugin is unavailable. Install/enable it on this Jellyfin server.')); };
        document.head.append(script);
    });
    return loading;
}
export function preparePortable(items) {
    // Preserve photo, music, subtitle and other non-video downloads.
    const videos = items.filter(i => i.item?.MediaType === 'Video' || ['Movie', 'Episode', 'Video', 'MusicVideo'].includes(i.item?.Type));
    if (!videos.length) return false;
    if (videos.length !== items.length) {
        window.alert('Download videos separately from music/photos to use Portable Downloads.');
        return true;
    }
    const serverId = videos[0].serverId;
    if (videos.some(i => i.serverId !== serverId)) {
        window.alert('Select videos from one server at a time.');
        return true;
    }
    const client = ServerConnections.getApiClient(serverId);
    const url = path => client.getUrl('PortableDownloads/' + path);
    const adapter = {
        async request(path, options = {}) {
            const response = await fetch(url(path), {
                method: options.method || 'GET',
                headers: { 'X-Emby-Token': client.accessToken(), 'Content-Type': 'application/json' },
                body: options.body == null ? undefined : JSON.stringify(options.body)
            });
            if (response.status === 204) return null;
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || `Jellyfin returned ${response.status}. Check plugin installation and user permissions.`);
            return data;
        },
        download(id, ticket) {
            const a = document.createElement('a');
            a.href = url(`jobs/${id}/file`) + '?ticket=' + encodeURIComponent(ticket);
            a.rel = 'noreferrer'; a.referrerPolicy = 'no-referrer';
            // Server Content-Disposition drives a streamed browser download; no Blob buffering.
            a.download = ''; document.body.append(a); a.click(); a.remove();
        }
    };
    load(url('ui/portable.js'))
        .then(() => window.PortableDownloads.open(videos, adapter, url('ui/portable.css')))
        .catch(error => window.alert(error.message));
    return true;
}
