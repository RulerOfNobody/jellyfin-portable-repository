#!/usr/bin/env node
// Deterministic source patch. Never search/replace minified bundles.
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const checkout = process.argv[2];
if (!checkout) throw new Error('Usage: node tools/patch-web.mjs /path/to/jellyfin-web');
const target = resolve(checkout, 'src/scripts/fileDownloader.js');
const bridge = join(dirname(target), 'portableBridge.js');
const text = readFileSync(target, 'utf8');
if (text.includes('portableBridge')) {
    console.log('Portable Downloads patch already applied.');
    process.exit(0);
}
const marker = 'export function download(items) {';
if (!text.includes(marker) || !text.includes('shell.downloadFiles(items)'))
    throw new Error('Unrecognized Jellyfin Web source. Refusing to patch.');
const backup = target + '.portable-backup';
if (existsSync(backup)) throw new Error('Backup already exists. Review the previous patch first.');
writeFileSync(backup, text);
writeFileSync(bridge, readFileSync(join(dirname(fileURLToPath(import.meta.url)), 'portableBridge.js'), 'utf8'));
writeFileSync(target, "import { preparePortable } from './portableBridge';\n" +
    text.replace(marker, marker + '\n    if (preparePortable(items)) return;'));
console.log('Patched the shared Download handler. Build Jellyfin Web and deploy its dist directory.');
