# Jellyfin Web and Moonfin integration

## Why there is a separate web adapter

The server plugin owns encoding, permissions, storage, queueing and downloads. A client owns its menus. Native apps do not execute arbitrary server-plugin JavaScript, so installing the DLL cannot universally replace their Download buttons.

This release modifies Jellyfin Web's shared `src/scripts/fileDownloader.js` handler. It routes video downloads to the options dialog and leaves photo/music downloads alone. It uses the active user's API session and the item's server ID. It does not scrape DOM item IDs, intercept unrelated requests, or silently download the full original when the plugin is unavailable.

Upstream integration point: [Jellyfin Web fileDownloader.js](https://github.com/jellyfin/jellyfin-web/blob/v10.11.11/src/scripts/fileDownloader.js).

## Building a matching web client

Requires Git, Node.js compatible with that Jellyfin Web release, and npm. Use an exact release tag that matches the server. Example:

```sh
git clone --branch v10.11.11 --depth 1 https://github.com/jellyfin/jellyfin-web.git
node /path/to/jellyfin-portable-downloads/tools/patch-web.mjs /path/to/jellyfin-web
cd /path/to/jellyfin-web
npm ci
npm run build:production
```

The patch is idempotent and creates `fileDownloader.js.portable-backup`. It refuses an unknown source layout rather than modifying minified JavaScript. Serve/bind-mount the resulting `dist` directory at the actual Jellyfin Web resources path in your container.

The initial GitHub release supplies a prebuilt patched **10.11.11** web archive with license notices. It does not supply a prebuilt 12.1 web archive.

## Native Moonfin and other clients

No native Moonfin patch is claimed. Once the exact Moonfin platform/version is known, its client can implement the same flow:

1. `GET /PortableDownloads/settings`: server backend and enabled codecs.
2. `GET /PortableDownloads/items/{itemId}`: authorized item metadata and selectable tracks.
3. `POST /PortableDownloads/jobs`: array of requests, each with its own `sizeGB`.
4. `GET /PortableDownloads/jobs`: that user's queue.
5. `POST /PortableDownloads/jobs/{jobId}/ticket`: obtain an expiring output-only ticket.
6. `GET /PortableDownloads/jobs/{jobId}/file?ticket=...`: stream or range-download the file.
7. `DELETE /PortableDownloads/jobs/{jobId}`: cancel/delete the temporary server job.

All endpoints except static UI assets and ticket-authorized file transfer require a Jellyfin user token. API-key-only administrative credentials are deliberately not accepted for user download jobs. The client is responsible for local offline-library integration and play-progress sync, if desired.

Example batch body:

```json
[
  {
    "itemId": "11111111-1111-4111-8111-111111111111",
    "sizeGB": 1.5,
    "codec": "hevc",
    "height": 1080,
    "audioIndex": null,
    "subtitleIndex": null
  }
]
```

The backend returns explicit errors for disabled codecs, denied permissions, full quotas, missing scratch markers and incompatible hardware choices. The dialog must show these rather than transparently switching codecs or downloading originals.
